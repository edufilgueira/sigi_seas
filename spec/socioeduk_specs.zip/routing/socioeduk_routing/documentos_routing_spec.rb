require "rails_helper"

RSpec.describe Socioeduk::DocumentosController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/documentos").to route_to("socioeduk/documentos#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/documentos/new").to route_to("socioeduk/documentos#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/documentos/1").to route_to("socioeduk/documentos#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/documentos/1/edit").to route_to("socioeduk/documentos#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/documentos").to route_to("socioeduk/documentos#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/documentos/1").to route_to("socioeduk/documentos#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/documentos/1").to route_to("socioeduk/documentos#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/documentos/1").to route_to("socioeduk/documentos#destroy", :id => "1")
    end

  end
end
