require "rails_helper"

RSpec.describe Socioeduk::AdmissaoAnexosController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/admissao_anexos").to route_to("socioeduk/admissao_anexos#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/admissao_anexos/new").to route_to("socioeduk/admissao_anexos#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/admissao_anexos/1").to route_to("socioeduk/admissao_anexos#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/admissao_anexos/1/edit").to route_to("socioeduk/admissao_anexos#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/admissao_anexos").to route_to("socioeduk/admissao_anexos#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/admissao_anexos/1").to route_to("socioeduk/admissao_anexos#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/admissao_anexos/1").to route_to("socioeduk/admissao_anexos#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/admissao_anexos/1").to route_to("socioeduk/admissao_anexos#destroy", :id => "1")
    end

  end
end
