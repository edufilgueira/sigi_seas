require "rails_helper"

RSpec.describe Socioeduk::InfracaoPreliminaresController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/infracao_preliminares").to route_to("socioeduk/infracao_preliminares#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/infracao_preliminares/new").to route_to("socioeduk/infracao_preliminares#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/infracao_preliminares/1").to route_to("socioeduk/infracao_preliminares#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/infracao_preliminares/1/edit").to route_to("socioeduk/infracao_preliminares#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/infracao_preliminares").to route_to("socioeduk/infracao_preliminares#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/infracao_preliminares/1").to route_to("socioeduk/infracao_preliminares#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/infracao_preliminares/1").to route_to("socioeduk/infracao_preliminares#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/infracao_preliminares/1").to route_to("socioeduk/infracao_preliminares#destroy", :id => "1")
    end

  end
end
