require "rails_helper"

RSpec.describe Socioeduk::EvasoesController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/evasoes").to route_to("socioeduk/evasoes#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/evasoes/new").to route_to("socioeduk/evasoes#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/evasoes/1").to route_to("socioeduk/evasoes#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/evasoes/1/edit").to route_to("socioeduk/evasoes#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/evasoes").to route_to("socioeduk/evasoes#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/evasoes/1").to route_to("socioeduk/evasoes#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/evasoes/1").to route_to("socioeduk/evasoes#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/evasoes/1").to route_to("socioeduk/evasoes#destroy", :id => "1")
    end

  end
end
