require "rails_helper"

RSpec.describe Socioeduk::OpcaoSexuaisController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/opcao_sexuais").to route_to("socioeduk/opcao_sexuais#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/opcao_sexuais/new").to route_to("socioeduk/opcao_sexuais#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/opcao_sexuais/1").to route_to("socioeduk/opcao_sexuais#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/opcao_sexuais/1/edit").to route_to("socioeduk/opcao_sexuais#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/opcao_sexuais").to route_to("socioeduk/opcao_sexuais#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/opcao_sexuais/1").to route_to("socioeduk/opcao_sexuais#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/opcao_sexuais/1").to route_to("socioeduk/opcao_sexuais#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/opcao_sexuais/1").to route_to("socioeduk/opcao_sexuais#destroy", :id => "1")
    end

  end
end
