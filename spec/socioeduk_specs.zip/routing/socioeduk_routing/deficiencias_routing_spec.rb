require "rails_helper"

RSpec.describe Socioeduk::DeficienciasController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/deficiencias").to route_to("socioeduk/deficiencias#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/deficiencias/new").to route_to("socioeduk/deficiencias#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/deficiencias/1").to route_to("socioeduk/deficiencias#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/deficiencias/1/edit").to route_to("socioeduk/deficiencias#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/deficiencias").to route_to("socioeduk/deficiencias#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/deficiencias/1").to route_to("socioeduk/deficiencias#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/deficiencias/1").to route_to("socioeduk/deficiencias#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/deficiencias/1").to route_to("socioeduk/deficiencias#destroy", :id => "1")
    end

  end
end
