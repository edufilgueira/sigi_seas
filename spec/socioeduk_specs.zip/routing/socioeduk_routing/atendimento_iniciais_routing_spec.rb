require "rails_helper"

RSpec.describe Socioeduk::AtendimentoIniciaisController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/atendimento_iniciais").to route_to("socioeduk/atendimento_iniciais#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/atendimento_iniciais/new").to route_to("socioeduk/atendimento_iniciais#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/atendimento_iniciais/1").to route_to("socioeduk/atendimento_iniciais#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/atendimento_iniciais/1/edit").to route_to("socioeduk/atendimento_iniciais#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/atendimento_iniciais").to route_to("socioeduk/atendimento_iniciais#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/atendimento_iniciais/1").to route_to("socioeduk/atendimento_iniciais#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/atendimento_iniciais/1").to route_to("socioeduk/atendimento_iniciais#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/atendimento_iniciais/1").to route_to("socioeduk/atendimento_iniciais#destroy", :id => "1")
    end

  end
end
