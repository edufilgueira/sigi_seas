require "rails_helper"

RSpec.describe Socioeduk::TipoDeficienciasController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/tipo_deficiencias").to route_to("socioeduk/tipo_deficiencias#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/tipo_deficiencias/new").to route_to("socioeduk/tipo_deficiencias#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/tipo_deficiencias/1").to route_to("socioeduk/tipo_deficiencias#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/tipo_deficiencias/1/edit").to route_to("socioeduk/tipo_deficiencias#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/tipo_deficiencias").to route_to("socioeduk/tipo_deficiencias#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/tipo_deficiencias/1").to route_to("socioeduk/tipo_deficiencias#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/tipo_deficiencias/1").to route_to("socioeduk/tipo_deficiencias#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/tipo_deficiencias/1").to route_to("socioeduk/tipo_deficiencias#destroy", :id => "1")
    end

  end
end
