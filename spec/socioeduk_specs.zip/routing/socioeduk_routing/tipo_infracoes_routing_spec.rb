require "rails_helper"

RSpec.describe Socioeduk::TipoInfracoesController, type: :routing do
  describe "routing" do

    it "routes to #index" do
      expect(:get => "/socioeduk/tipo_infracoes").to route_to("socioeduk/tipo_infracoes#index")
    end

    it "routes to #new" do
      expect(:get => "/socioeduk/tipo_infracoes/new").to route_to("socioeduk/tipo_infracoes#new")
    end

    it "routes to #show" do
      expect(:get => "/socioeduk/tipo_infracoes/1").to route_to("socioeduk/tipo_infracoes#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/socioeduk/tipo_infracoes/1/edit").to route_to("socioeduk/tipo_infracoes#edit", :id => "1")
    end

    it "routes to #create" do
      expect(:post => "/socioeduk/tipo_infracoes").to route_to("socioeduk/tipo_infracoes#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/socioeduk/tipo_infracoes/1").to route_to("socioeduk/tipo_infracoes#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/socioeduk/tipo_infracoes/1").to route_to("socioeduk/tipo_infracoes#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/socioeduk/tipo_infracoes/1").to route_to("socioeduk/tipo_infracoes#destroy", :id => "1")
    end

  end
end
