FactoryGirl.define do
  factory :socioeduk_jovem, class: 'Socioeduk::Jovem' do
    nome "MyString"
    apelido "MyString"
    falecido false
    data_nascimento "2017-11-22"
    sexo 1
    opcao_sexual nil
    nome_mae "MyString"
    nome_pai "MyString"
    peso ""
    altura ""
    dependente_quimico false
    nacionalidade "MyString"
    naturalidade "MyString"
    etnia "MyString"
    estado_civil_id "MyString"
    orfao false
    responsavel "MyString"
    mora_com "MyString"
    numero_filhos 1
    responsavel_filhos "MyString"
    tempo_gestacao "MyString"
    amamentando false
    foto ""
  end
end
