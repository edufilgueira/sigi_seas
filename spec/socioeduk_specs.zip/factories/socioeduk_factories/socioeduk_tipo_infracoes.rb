FactoryGirl.define do
  factory :socioeduk_tipo_infracao, class: 'Socioeduk::TipoInfracao' do
    artigo "MyString"
    nome "MyString"
    descricao "MyString"
  end
end
