FactoryGirl.define do
  factory :socioeduk_documento, class: 'Socioeduk::Documento' do
    jovem nil
    cpf "MyString"
    rg_numero "MyString"
    rg_data_emissao "2017-11-22"
    rg_orgao_emissor "MyString"
    rg_uf_emissao "MyString"
    certidao_nascimento "MyString"
    certidao_numero "MyString"
    certidao_pagina "MyString"
    certidao_livro "MyString"
    certidao_data_emissao "2017-11-22"
    certidao_uf_emissao "MyString"
    cpts_numero "MyString"
    ctps_serie "MyString"
    ctps_data_emissao "MyString"
    ctps_uf_emissao "MyString"
    titulo_numero "MyString"
    titulo_serie "MyString"
    titulo_secao "MyString"
    pis_numero "MyString"
    reservista_numero "MyString"
    deleted_at "2017-11-22 01:03:14"
  end
end
