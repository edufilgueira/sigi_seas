FactoryGirl.define do
  factory :socioeduk_infracao, class: 'Socioeduk::Infracao' do
    jovem nil
    tipo_infracao nil
  end
end
