FactoryGirl.define do
  factory :socioeduk_deficiencia, class: 'Socioeduk::Deficiencia' do
    jovem nil
    deficiencias nil
  end
end
