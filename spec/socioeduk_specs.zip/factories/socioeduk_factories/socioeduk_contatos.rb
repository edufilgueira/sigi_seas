FactoryGirl.define do
  factory :socioeduk_contato, class: 'Socioeduk::Contato' do
    jovem nil
    tipo_contato nil
    ddd 1
    numero "MyString"
  end
end
