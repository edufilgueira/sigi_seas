FactoryGirl.define do
  factory :socioeduk_admissao_anexo, class: 'Socioeduk::AdmissaoAnexo' do
    jovem nil
    kit ""
    documentos ""
  end
end
