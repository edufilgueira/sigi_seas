FactoryGirl.define do
  factory :socioeduk_subforma_entrada, class: 'Socioeduk::SubformaEntrada' do
    descricao "MyString"
    forma_entrada nil
  end
end
