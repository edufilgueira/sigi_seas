FactoryGirl.define do
  factory :socioeduk_evasao, class: 'Socioeduk::Evasao' do
    jovem nil
    data_evasao "2017-11-22 01:04:28"
    evadido false
    retornou_em "2017-11-22 01:04:28"
    tipo_evasao 1
    observacoes "MyText"
    motivo "MyString"
  end
end
