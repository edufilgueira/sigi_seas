FactoryGirl.define do
  factory :socioeduk_marca_corporal, class: 'Socioeduk::MarcaCorporal' do
    jovem nil
    marca_corporal nil
  end
end
