FactoryGirl.define do
  factory :socioeduk_documento_forma_entrada, class: 'Socioeduk::DocumentoFormaEntrada' do
    descricao "MyString"
    obrigatorio false
    forma_entrada nil
    subforma_entrada nil
  end
end
