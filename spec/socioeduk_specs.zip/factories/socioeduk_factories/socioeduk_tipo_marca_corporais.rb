FactoryGirl.define do
  factory :socioeduk_tipo_marca_corporal, class: 'Socioeduk::TipoMarcaCorporal' do
    descricao "MyString"
  end
end
