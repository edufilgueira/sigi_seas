FactoryGirl.define do
  factory :socioeduk_forma_entrada, class: 'Socioeduk::FormaEntrada' do
    descricao "MyString"
  end
end
