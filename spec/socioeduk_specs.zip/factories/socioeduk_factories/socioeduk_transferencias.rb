FactoryGirl.define do
  factory :socioeduk_transferencia, class: 'Socioeduk::Transferencia' do
    unidade_socioeducativa_origem_id 1
    unidade_socioeducativa_destino_id 1
    admissao nil
  end
end
