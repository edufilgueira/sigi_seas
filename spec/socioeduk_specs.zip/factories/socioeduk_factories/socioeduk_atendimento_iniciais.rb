FactoryGirl.define do
  factory :socioeduk_atendimento_inicial, class: 'Socioeduk::AtendimentoInicial' do
    jovem nil
    unidade_socioeducativa nil
    entrada_em "2017-11-22 01:04:03"
    reincidente false
    cumpre_medida false
    qual_medida "MyString"
    cidade_infracao "MyString"
    bairro_infracao "MyString"
    busca_apreensao false
    cidade_origem_processo 1
    cidade_execucao_processo 1
    numero_oficio_bo "MyString"
    comarca_origem "MyString"
    procedencia "MyString"
    numero_processo "MyString"
    guia_corpo_delito false
    alcoolizado false
    drogado false
    ematomas false
    agressor "MyString"
    observacoes "MyText"
    nome_condutor "MyString"
    funcao_condutor "MyString"
    rg_condutor "MyString"
    encaminhado false
    encaminhado_em "2017-11-22 01:04:03"
    tipo_desligamento nil
    desligado_em "2017-11-22 01:04:03"
    deleted_at "2017-11-22 01:04:03"
  end
end
