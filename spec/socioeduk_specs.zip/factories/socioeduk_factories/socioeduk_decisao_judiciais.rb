FactoryGirl.define do
  factory :socioeduk_decisao_judicial, class: 'Socioeduk::DecisaoJudicial' do
    descricao "MyString"
    atendimento_inicial nil
    documento ""
  end
end
