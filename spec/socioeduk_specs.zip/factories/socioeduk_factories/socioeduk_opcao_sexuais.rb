FactoryGirl.define do
  factory :socioeduk_opcao_sexual, class: 'Socioeduk::OpcaoSexual' do
    descricao "MyString"
  end
end
