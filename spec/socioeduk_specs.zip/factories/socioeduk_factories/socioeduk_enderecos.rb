FactoryGirl.define do
  factory :socioeduk_endereco, class: 'Socioeduk::Endereco' do
    cep "MyString"
    logradouro "MyString"
    numero "MyString"
    bairro "MyString"
    complemento "MyString"
    cidade "MyString"
    estado "MyString"
    ponto_referencia "MyString"
    tipo 1
  end
end
