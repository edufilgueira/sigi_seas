FactoryGirl.define do
  factory :socioeduk_tipo_contato, class: 'Socioeduk::TipoContato' do
    descricao "MyString"
  end
end
