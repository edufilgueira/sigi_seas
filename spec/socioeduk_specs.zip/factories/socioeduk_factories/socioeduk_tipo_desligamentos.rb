FactoryGirl.define do
  factory :socioeduk_tipo_desligamento, class: 'Socioeduk::TipoDesligamento' do
    descricao "MyString"
  end
end
