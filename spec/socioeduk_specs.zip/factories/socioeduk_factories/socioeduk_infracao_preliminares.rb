FactoryGirl.define do
  factory :socioeduk_infracao_preliminar, class: 'Socioeduk::InfracaoPreliminar' do
    atendimento_inicial nil
    tipo_infracao nil
  end
end
