FactoryGirl.define do
  factory :socioeduk_admissao, class: 'Socioeduk::Admissao' do
    jovem nil
    unidade_socioeducativa nil
    rebebido_em "2017-11-22 01:03:21"
    tipo_desligamento nil
    desligado_em "2017-11-22 01:03:21"
    numero_processo "MyString"
  end
end
