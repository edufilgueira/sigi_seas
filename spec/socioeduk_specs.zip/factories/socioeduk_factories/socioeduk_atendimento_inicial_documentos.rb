FactoryGirl.define do
  factory :socioeduk_atendimento_inicial_documento, class: 'Socioeduk::AtendimentoInicialDocumento' do
    descricao "MyString"
    atendimento_inicial nil
    documento_forma_entrada nil
    documento ""
  end
end
