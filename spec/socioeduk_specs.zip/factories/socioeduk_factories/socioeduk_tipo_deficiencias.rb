FactoryGirl.define do
  factory :socioeduk_tipo_deficiencia, class: 'Socioeduk::TipoDeficiencia' do
    descricao "MyString"
  end
end
