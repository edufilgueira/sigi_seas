require 'rails_helper'

RSpec.describe "socioeduk/admissoes/edit", type: :view do
  before(:each) do
    @socioeduk_admissao = assign(:socioeduk_admissao, Socioeduk::Admissao.create!(
      :jovem => nil,
      :unidade_socioeducativa => nil,
      :tipo_desligamento => nil,
      :numero_processo => "MyString"
    ))
  end

  it "renders the edit socioeduk_admissao form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_admissao_path(@socioeduk_admissao), "post" do

      assert_select "input[name=?]", "socioeduk_admissao[jovem_id]"

      assert_select "input[name=?]", "socioeduk_admissao[unidade_socioeducativa_id]"

      assert_select "input[name=?]", "socioeduk_admissao[tipo_desligamento_id]"

      assert_select "input[name=?]", "socioeduk_admissao[numero_processo]"
    end
  end
end
