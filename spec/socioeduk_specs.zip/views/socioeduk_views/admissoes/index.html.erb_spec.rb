require 'rails_helper'

RSpec.describe "socioeduk/admissoes/index", type: :view do
  before(:each) do
    assign(:socioeduk_admissoes, [
      Socioeduk::Admissao.create!(
        :jovem => nil,
        :unidade_socioeducativa => nil,
        :tipo_desligamento => nil,
        :numero_processo => "Numero Processo"
      ),
      Socioeduk::Admissao.create!(
        :jovem => nil,
        :unidade_socioeducativa => nil,
        :tipo_desligamento => nil,
        :numero_processo => "Numero Processo"
      )
    ])
  end

  it "renders a list of socioeduk/admissoes" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => "Numero Processo".to_s, :count => 2
  end
end
