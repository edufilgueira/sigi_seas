require 'rails_helper'

RSpec.describe "socioeduk/admissoes/show", type: :view do
  before(:each) do
    @socioeduk_admissao = assign(:socioeduk_admissao, Socioeduk::Admissao.create!(
      :jovem => nil,
      :unidade_socioeducativa => nil,
      :tipo_desligamento => nil,
      :numero_processo => "Numero Processo"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(//)
    expect(rendered).to match(//)
    expect(rendered).to match(/Numero Processo/)
  end
end
