require 'rails_helper'

RSpec.describe "socioeduk/marca_corporais/edit", type: :view do
  before(:each) do
    @socioeduk_marca_corporal = assign(:socioeduk_marca_corporal, Socioeduk::MarcaCorporal.create!(
      :jovem => nil,
      :marca_corporal => nil
    ))
  end

  it "renders the edit socioeduk_marca_corporal form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_marca_corporal_path(@socioeduk_marca_corporal), "post" do

      assert_select "input[name=?]", "socioeduk_marca_corporal[jovem_id]"

      assert_select "input[name=?]", "socioeduk_marca_corporal[marca_corporal_id]"
    end
  end
end
