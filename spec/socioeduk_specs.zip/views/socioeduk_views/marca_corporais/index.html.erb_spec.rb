require 'rails_helper'

RSpec.describe "socioeduk/marca_corporais/index", type: :view do
  before(:each) do
    assign(:socioeduk_marca_corporais, [
      Socioeduk::MarcaCorporal.create!(
        :jovem => nil,
        :marca_corporal => nil
      ),
      Socioeduk::MarcaCorporal.create!(
        :jovem => nil,
        :marca_corporal => nil
      )
    ])
  end

  it "renders a list of socioeduk/marca_corporais" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
  end
end
