require 'rails_helper'

RSpec.describe "socioeduk/marca_corporais/show", type: :view do
  before(:each) do
    @socioeduk_marca_corporal = assign(:socioeduk_marca_corporal, Socioeduk::MarcaCorporal.create!(
      :jovem => nil,
      :marca_corporal => nil
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(//)
  end
end
