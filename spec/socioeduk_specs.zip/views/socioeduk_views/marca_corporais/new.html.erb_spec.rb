require 'rails_helper'

RSpec.describe "socioeduk/marca_corporais/new", type: :view do
  before(:each) do
    assign(:socioeduk_marca_corporal, Socioeduk::MarcaCorporal.new(
      :jovem => nil,
      :marca_corporal => nil
    ))
  end

  it "renders new socioeduk_marca_corporal form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_marca_corporais_path, "post" do

      assert_select "input[name=?]", "socioeduk_marca_corporal[jovem_id]"

      assert_select "input[name=?]", "socioeduk_marca_corporal[marca_corporal_id]"
    end
  end
end
