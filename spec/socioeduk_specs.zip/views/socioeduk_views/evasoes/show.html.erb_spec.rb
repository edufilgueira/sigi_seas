require 'rails_helper'

RSpec.describe "socioeduk/evasoes/show", type: :view do
  before(:each) do
    @socioeduk_evasao = assign(:socioeduk_evasao, Socioeduk::Evasao.create!(
      :jovem => nil,
      :evadido => false,
      :tipo_evasao => 2,
      :observacoes => "MyText",
      :motivo => "Motivo"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/2/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/Motivo/)
  end
end
