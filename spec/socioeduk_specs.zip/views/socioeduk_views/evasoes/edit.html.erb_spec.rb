require 'rails_helper'

RSpec.describe "socioeduk/evasoes/edit", type: :view do
  before(:each) do
    @socioeduk_evasao = assign(:socioeduk_evasao, Socioeduk::Evasao.create!(
      :jovem => nil,
      :evadido => false,
      :tipo_evasao => 1,
      :observacoes => "MyText",
      :motivo => "MyString"
    ))
  end

  it "renders the edit socioeduk_evasao form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_evasao_path(@socioeduk_evasao), "post" do

      assert_select "input[name=?]", "socioeduk_evasao[jovem_id]"

      assert_select "input[name=?]", "socioeduk_evasao[evadido]"

      assert_select "input[name=?]", "socioeduk_evasao[tipo_evasao]"

      assert_select "textarea[name=?]", "socioeduk_evasao[observacoes]"

      assert_select "input[name=?]", "socioeduk_evasao[motivo]"
    end
  end
end
