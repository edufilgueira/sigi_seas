require 'rails_helper'

RSpec.describe "socioeduk/evasoes/index", type: :view do
  before(:each) do
    assign(:socioeduk_evasoes, [
      Socioeduk::Evasao.create!(
        :jovem => nil,
        :evadido => false,
        :tipo_evasao => 2,
        :observacoes => "MyText",
        :motivo => "Motivo"
      ),
      Socioeduk::Evasao.create!(
        :jovem => nil,
        :evadido => false,
        :tipo_evasao => 2,
        :observacoes => "MyText",
        :motivo => "Motivo"
      )
    ])
  end

  it "renders a list of socioeduk/evasoes" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "Motivo".to_s, :count => 2
  end
end
