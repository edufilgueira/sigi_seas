require 'rails_helper'

RSpec.describe "socioeduk/enderecos/new", type: :view do
  before(:each) do
    assign(:socioeduk_endereco, Socioeduk::Endereco.new(
      :cep => "MyString",
      :logradouro => "MyString",
      :numero => "MyString",
      :bairro => "MyString",
      :complemento => "MyString",
      :cidade => "MyString",
      :estado => "MyString",
      :ponto_referencia => "MyString",
      :tipo => 1
    ))
  end

  it "renders new socioeduk_endereco form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_enderecos_path, "post" do

      assert_select "input[name=?]", "socioeduk_endereco[cep]"

      assert_select "input[name=?]", "socioeduk_endereco[logradouro]"

      assert_select "input[name=?]", "socioeduk_endereco[numero]"

      assert_select "input[name=?]", "socioeduk_endereco[bairro]"

      assert_select "input[name=?]", "socioeduk_endereco[complemento]"

      assert_select "input[name=?]", "socioeduk_endereco[cidade]"

      assert_select "input[name=?]", "socioeduk_endereco[estado]"

      assert_select "input[name=?]", "socioeduk_endereco[ponto_referencia]"

      assert_select "input[name=?]", "socioeduk_endereco[tipo]"
    end
  end
end
