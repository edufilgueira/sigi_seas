require 'rails_helper'

RSpec.describe "socioeduk/enderecos/edit", type: :view do
  before(:each) do
    @socioeduk_endereco = assign(:socioeduk_endereco, Socioeduk::Endereco.create!(
      :cep => "MyString",
      :logradouro => "MyString",
      :numero => "MyString",
      :bairro => "MyString",
      :complemento => "MyString",
      :cidade => "MyString",
      :estado => "MyString",
      :ponto_referencia => "MyString",
      :tipo => 1
    ))
  end

  it "renders the edit socioeduk_endereco form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_endereco_path(@socioeduk_endereco), "post" do

      assert_select "input[name=?]", "socioeduk_endereco[cep]"

      assert_select "input[name=?]", "socioeduk_endereco[logradouro]"

      assert_select "input[name=?]", "socioeduk_endereco[numero]"

      assert_select "input[name=?]", "socioeduk_endereco[bairro]"

      assert_select "input[name=?]", "socioeduk_endereco[complemento]"

      assert_select "input[name=?]", "socioeduk_endereco[cidade]"

      assert_select "input[name=?]", "socioeduk_endereco[estado]"

      assert_select "input[name=?]", "socioeduk_endereco[ponto_referencia]"

      assert_select "input[name=?]", "socioeduk_endereco[tipo]"
    end
  end
end
