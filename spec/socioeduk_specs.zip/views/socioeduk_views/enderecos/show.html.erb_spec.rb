require 'rails_helper'

RSpec.describe "socioeduk/enderecos/show", type: :view do
  before(:each) do
    @socioeduk_endereco = assign(:socioeduk_endereco, Socioeduk::Endereco.create!(
      :cep => "Cep",
      :logradouro => "Logradouro",
      :numero => "Numero",
      :bairro => "Bairro",
      :complemento => "Complemento",
      :cidade => "Cidade",
      :estado => "Estado",
      :ponto_referencia => "Ponto Referencia",
      :tipo => 2
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Cep/)
    expect(rendered).to match(/Logradouro/)
    expect(rendered).to match(/Numero/)
    expect(rendered).to match(/Bairro/)
    expect(rendered).to match(/Complemento/)
    expect(rendered).to match(/Cidade/)
    expect(rendered).to match(/Estado/)
    expect(rendered).to match(/Ponto Referencia/)
    expect(rendered).to match(/2/)
  end
end
