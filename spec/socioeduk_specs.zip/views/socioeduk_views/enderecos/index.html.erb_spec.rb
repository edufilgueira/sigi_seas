require 'rails_helper'

RSpec.describe "socioeduk/enderecos/index", type: :view do
  before(:each) do
    assign(:socioeduk_enderecos, [
      Socioeduk::Endereco.create!(
        :cep => "Cep",
        :logradouro => "Logradouro",
        :numero => "Numero",
        :bairro => "Bairro",
        :complemento => "Complemento",
        :cidade => "Cidade",
        :estado => "Estado",
        :ponto_referencia => "Ponto Referencia",
        :tipo => 2
      ),
      Socioeduk::Endereco.create!(
        :cep => "Cep",
        :logradouro => "Logradouro",
        :numero => "Numero",
        :bairro => "Bairro",
        :complemento => "Complemento",
        :cidade => "Cidade",
        :estado => "Estado",
        :ponto_referencia => "Ponto Referencia",
        :tipo => 2
      )
    ])
  end

  it "renders a list of socioeduk/enderecos" do
    render
    assert_select "tr>td", :text => "Cep".to_s, :count => 2
    assert_select "tr>td", :text => "Logradouro".to_s, :count => 2
    assert_select "tr>td", :text => "Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Bairro".to_s, :count => 2
    assert_select "tr>td", :text => "Complemento".to_s, :count => 2
    assert_select "tr>td", :text => "Cidade".to_s, :count => 2
    assert_select "tr>td", :text => "Estado".to_s, :count => 2
    assert_select "tr>td", :text => "Ponto Referencia".to_s, :count => 2
    assert_select "tr>td", :text => 2.to_s, :count => 2
  end
end
