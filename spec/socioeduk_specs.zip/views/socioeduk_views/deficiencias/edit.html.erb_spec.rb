require 'rails_helper'

RSpec.describe "socioeduk/deficiencias/edit", type: :view do
  before(:each) do
    @socioeduk_deficiencia = assign(:socioeduk_deficiencia, Socioeduk::Deficiencia.create!(
      :jovem => nil,
      :deficiencias => nil
    ))
  end

  it "renders the edit socioeduk_deficiencia form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_deficiencia_path(@socioeduk_deficiencia), "post" do

      assert_select "input[name=?]", "socioeduk_deficiencia[jovem_id]"

      assert_select "input[name=?]", "socioeduk_deficiencia[deficiencias_id]"
    end
  end
end
