require 'rails_helper'

RSpec.describe "socioeduk/deficiencias/index", type: :view do
  before(:each) do
    assign(:socioeduk_deficiencias, [
      Socioeduk::Deficiencia.create!(
        :jovem => nil,
        :deficiencias => nil
      ),
      Socioeduk::Deficiencia.create!(
        :jovem => nil,
        :deficiencias => nil
      )
    ])
  end

  it "renders a list of socioeduk/deficiencias" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
  end
end
