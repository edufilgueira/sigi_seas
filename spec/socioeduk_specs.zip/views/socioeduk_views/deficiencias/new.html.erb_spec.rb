require 'rails_helper'

RSpec.describe "socioeduk/deficiencias/new", type: :view do
  before(:each) do
    assign(:socioeduk_deficiencia, Socioeduk::Deficiencia.new(
      :jovem => nil,
      :deficiencias => nil
    ))
  end

  it "renders new socioeduk_deficiencia form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_deficiencias_path, "post" do

      assert_select "input[name=?]", "socioeduk_deficiencia[jovem_id]"

      assert_select "input[name=?]", "socioeduk_deficiencia[deficiencias_id]"
    end
  end
end
