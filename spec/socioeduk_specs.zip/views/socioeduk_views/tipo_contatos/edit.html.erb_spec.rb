require 'rails_helper'

RSpec.describe "socioeduk/tipo_contatos/edit", type: :view do
  before(:each) do
    @socioeduk_tipo_contato = assign(:socioeduk_tipo_contato, Socioeduk::TipoContato.create!(
      :descricao => "MyString"
    ))
  end

  it "renders the edit socioeduk_tipo_contato form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_tipo_contato_path(@socioeduk_tipo_contato), "post" do

      assert_select "input[name=?]", "socioeduk_tipo_contato[descricao]"
    end
  end
end
