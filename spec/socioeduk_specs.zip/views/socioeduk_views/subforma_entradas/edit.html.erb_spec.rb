require 'rails_helper'

RSpec.describe "socioeduk/subforma_entradas/edit", type: :view do
  before(:each) do
    @socioeduk_subforma_entrada = assign(:socioeduk_subforma_entrada, Socioeduk::SubformaEntrada.create!(
      :descricao => "MyString",
      :forma_entrada => nil
    ))
  end

  it "renders the edit socioeduk_subforma_entrada form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_subforma_entrada_path(@socioeduk_subforma_entrada), "post" do

      assert_select "input[name=?]", "socioeduk_subforma_entrada[descricao]"

      assert_select "input[name=?]", "socioeduk_subforma_entrada[forma_entrada_id]"
    end
  end
end
