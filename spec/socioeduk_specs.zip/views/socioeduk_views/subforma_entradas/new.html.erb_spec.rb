require 'rails_helper'

RSpec.describe "socioeduk/subforma_entradas/new", type: :view do
  before(:each) do
    assign(:socioeduk_subforma_entrada, Socioeduk::SubformaEntrada.new(
      :descricao => "MyString",
      :forma_entrada => nil
    ))
  end

  it "renders new socioeduk_subforma_entrada form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_subforma_entradas_path, "post" do

      assert_select "input[name=?]", "socioeduk_subforma_entrada[descricao]"

      assert_select "input[name=?]", "socioeduk_subforma_entrada[forma_entrada_id]"
    end
  end
end
