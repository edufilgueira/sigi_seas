require 'rails_helper'

RSpec.describe "socioeduk/subforma_entradas/show", type: :view do
  before(:each) do
    @socioeduk_subforma_entrada = assign(:socioeduk_subforma_entrada, Socioeduk::SubformaEntrada.create!(
      :descricao => "Descricao",
      :forma_entrada => nil
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
    expect(rendered).to match(//)
  end
end
