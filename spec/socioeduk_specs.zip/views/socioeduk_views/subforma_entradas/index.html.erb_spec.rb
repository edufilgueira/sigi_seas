require 'rails_helper'

RSpec.describe "socioeduk/subforma_entradas/index", type: :view do
  before(:each) do
    assign(:socioeduk_subforma_entradas, [
      Socioeduk::SubformaEntrada.create!(
        :descricao => "Descricao",
        :forma_entrada => nil
      ),
      Socioeduk::SubformaEntrada.create!(
        :descricao => "Descricao",
        :forma_entrada => nil
      )
    ])
  end

  it "renders a list of socioeduk/subforma_entradas" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
  end
end
