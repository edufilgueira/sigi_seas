require 'rails_helper'

RSpec.describe "socioeduk/infracao_preliminares/new", type: :view do
  before(:each) do
    assign(:socioeduk_infracao_preliminar, Socioeduk::InfracaoPreliminar.new(
      :atendimento_inicial => nil,
      :tipo_infracao => nil
    ))
  end

  it "renders new socioeduk_infracao_preliminar form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_infracao_preliminares_path, "post" do

      assert_select "input[name=?]", "socioeduk_infracao_preliminar[atendimento_inicial_id]"

      assert_select "input[name=?]", "socioeduk_infracao_preliminar[tipo_infracao_id]"
    end
  end
end
