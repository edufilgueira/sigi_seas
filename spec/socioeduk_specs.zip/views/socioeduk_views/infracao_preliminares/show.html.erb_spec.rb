require 'rails_helper'

RSpec.describe "socioeduk/infracao_preliminares/show", type: :view do
  before(:each) do
    @socioeduk_infracao_preliminar = assign(:socioeduk_infracao_preliminar, Socioeduk::InfracaoPreliminar.create!(
      :atendimento_inicial => nil,
      :tipo_infracao => nil
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(//)
  end
end
