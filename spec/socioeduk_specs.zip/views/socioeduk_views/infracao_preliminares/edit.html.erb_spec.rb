require 'rails_helper'

RSpec.describe "socioeduk/infracao_preliminares/edit", type: :view do
  before(:each) do
    @socioeduk_infracao_preliminar = assign(:socioeduk_infracao_preliminar, Socioeduk::InfracaoPreliminar.create!(
      :atendimento_inicial => nil,
      :tipo_infracao => nil
    ))
  end

  it "renders the edit socioeduk_infracao_preliminar form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_infracao_preliminar_path(@socioeduk_infracao_preliminar), "post" do

      assert_select "input[name=?]", "socioeduk_infracao_preliminar[atendimento_inicial_id]"

      assert_select "input[name=?]", "socioeduk_infracao_preliminar[tipo_infracao_id]"
    end
  end
end
