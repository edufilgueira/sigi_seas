require 'rails_helper'

RSpec.describe "socioeduk/tipo_desligamentos/show", type: :view do
  before(:each) do
    @socioeduk_tipo_desligamento = assign(:socioeduk_tipo_desligamento, Socioeduk::TipoDesligamento.create!(
      :descricao => "Descricao"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
  end
end
