require 'rails_helper'

RSpec.describe "socioeduk/tipo_desligamentos/index", type: :view do
  before(:each) do
    assign(:socioeduk_tipo_desligamentos, [
      Socioeduk::TipoDesligamento.create!(
        :descricao => "Descricao"
      ),
      Socioeduk::TipoDesligamento.create!(
        :descricao => "Descricao"
      )
    ])
  end

  it "renders a list of socioeduk/tipo_desligamentos" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
  end
end
