require 'rails_helper'

RSpec.describe "socioeduk/tipo_infracoes/show", type: :view do
  before(:each) do
    @socioeduk_tipo_infracao = assign(:socioeduk_tipo_infracao, Socioeduk::TipoInfracao.create!(
      :artigo => "Artigo",
      :nome => "Nome",
      :descricao => "Descricao"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Artigo/)
    expect(rendered).to match(/Nome/)
    expect(rendered).to match(/Descricao/)
  end
end
