require 'rails_helper'

RSpec.describe "socioeduk/tipo_infracoes/index", type: :view do
  before(:each) do
    assign(:socioeduk_tipo_infracoes, [
      Socioeduk::TipoInfracao.create!(
        :artigo => "Artigo",
        :nome => "Nome",
        :descricao => "Descricao"
      ),
      Socioeduk::TipoInfracao.create!(
        :artigo => "Artigo",
        :nome => "Nome",
        :descricao => "Descricao"
      )
    ])
  end

  it "renders a list of socioeduk/tipo_infracoes" do
    render
    assert_select "tr>td", :text => "Artigo".to_s, :count => 2
    assert_select "tr>td", :text => "Nome".to_s, :count => 2
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
  end
end
