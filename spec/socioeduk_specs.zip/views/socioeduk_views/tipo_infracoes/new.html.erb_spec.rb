require 'rails_helper'

RSpec.describe "socioeduk/tipo_infracoes/new", type: :view do
  before(:each) do
    assign(:socioeduk_tipo_infracao, Socioeduk::TipoInfracao.new(
      :artigo => "MyString",
      :nome => "MyString",
      :descricao => "MyString"
    ))
  end

  it "renders new socioeduk_tipo_infracao form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_tipo_infracoes_path, "post" do

      assert_select "input[name=?]", "socioeduk_tipo_infracao[artigo]"

      assert_select "input[name=?]", "socioeduk_tipo_infracao[nome]"

      assert_select "input[name=?]", "socioeduk_tipo_infracao[descricao]"
    end
  end
end
