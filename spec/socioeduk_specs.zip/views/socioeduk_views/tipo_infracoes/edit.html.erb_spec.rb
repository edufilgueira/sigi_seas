require 'rails_helper'

RSpec.describe "socioeduk/tipo_infracoes/edit", type: :view do
  before(:each) do
    @socioeduk_tipo_infracao = assign(:socioeduk_tipo_infracao, Socioeduk::TipoInfracao.create!(
      :artigo => "MyString",
      :nome => "MyString",
      :descricao => "MyString"
    ))
  end

  it "renders the edit socioeduk_tipo_infracao form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_tipo_infracao_path(@socioeduk_tipo_infracao), "post" do

      assert_select "input[name=?]", "socioeduk_tipo_infracao[artigo]"

      assert_select "input[name=?]", "socioeduk_tipo_infracao[nome]"

      assert_select "input[name=?]", "socioeduk_tipo_infracao[descricao]"
    end
  end
end
