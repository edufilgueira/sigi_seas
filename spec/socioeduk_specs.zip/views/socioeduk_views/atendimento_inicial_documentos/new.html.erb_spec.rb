require 'rails_helper'

RSpec.describe "socioeduk/atendimento_inicial_documentos/new", type: :view do
  before(:each) do
    assign(:socioeduk_atendimento_inicial_documento, Socioeduk::AtendimentoInicialDocumento.new(
      :descricao => "MyString",
      :atendimento_inicial => nil,
      :documento_forma_entrada => nil,
      :documento => ""
    ))
  end

  it "renders new socioeduk_atendimento_inicial_documento form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_atendimento_inicial_documentos_path, "post" do

      assert_select "input[name=?]", "socioeduk_atendimento_inicial_documento[descricao]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial_documento[atendimento_inicial_id]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial_documento[documento_forma_entrada_id]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial_documento[documento]"
    end
  end
end
