require 'rails_helper'

RSpec.describe "socioeduk/atendimento_inicial_documentos/show", type: :view do
  before(:each) do
    @socioeduk_atendimento_inicial_documento = assign(:socioeduk_atendimento_inicial_documento, Socioeduk::AtendimentoInicialDocumento.create!(
      :descricao => "Descricao",
      :atendimento_inicial => nil,
      :documento_forma_entrada => nil,
      :documento => ""
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
    expect(rendered).to match(//)
    expect(rendered).to match(//)
    expect(rendered).to match(//)
  end
end
