require 'rails_helper'

RSpec.describe "socioeduk/atendimento_inicial_documentos/index", type: :view do
  before(:each) do
    assign(:socioeduk_atendimento_inicial_documentos, [
      Socioeduk::AtendimentoInicialDocumento.create!(
        :descricao => "Descricao",
        :atendimento_inicial => nil,
        :documento_forma_entrada => nil,
        :documento => ""
      ),
      Socioeduk::AtendimentoInicialDocumento.create!(
        :descricao => "Descricao",
        :atendimento_inicial => nil,
        :documento_forma_entrada => nil,
        :documento => ""
      )
    ])
  end

  it "renders a list of socioeduk/atendimento_inicial_documentos" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
  end
end
