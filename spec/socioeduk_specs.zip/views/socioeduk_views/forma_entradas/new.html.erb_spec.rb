require 'rails_helper'

RSpec.describe "socioeduk/forma_entradas/new", type: :view do
  before(:each) do
    assign(:socioeduk_forma_entrada, Socioeduk::FormaEntrada.new(
      :descricao => "MyString"
    ))
  end

  it "renders new socioeduk_forma_entrada form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_forma_entradas_path, "post" do

      assert_select "input[name=?]", "socioeduk_forma_entrada[descricao]"
    end
  end
end
