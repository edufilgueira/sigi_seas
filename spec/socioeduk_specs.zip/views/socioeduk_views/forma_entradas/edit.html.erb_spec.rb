require 'rails_helper'

RSpec.describe "socioeduk/forma_entradas/edit", type: :view do
  before(:each) do
    @socioeduk_forma_entrada = assign(:socioeduk_forma_entrada, Socioeduk::FormaEntrada.create!(
      :descricao => "MyString"
    ))
  end

  it "renders the edit socioeduk_forma_entrada form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_forma_entrada_path(@socioeduk_forma_entrada), "post" do

      assert_select "input[name=?]", "socioeduk_forma_entrada[descricao]"
    end
  end
end
