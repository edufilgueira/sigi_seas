require 'rails_helper'

RSpec.describe "socioeduk/forma_entradas/index", type: :view do
  before(:each) do
    assign(:socioeduk_forma_entradas, [
      Socioeduk::FormaEntrada.create!(
        :descricao => "Descricao"
      ),
      Socioeduk::FormaEntrada.create!(
        :descricao => "Descricao"
      )
    ])
  end

  it "renders a list of socioeduk/forma_entradas" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
  end
end
