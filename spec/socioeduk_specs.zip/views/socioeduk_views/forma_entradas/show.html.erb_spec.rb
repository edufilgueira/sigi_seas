require 'rails_helper'

RSpec.describe "socioeduk/forma_entradas/show", type: :view do
  before(:each) do
    @socioeduk_forma_entrada = assign(:socioeduk_forma_entrada, Socioeduk::FormaEntrada.create!(
      :descricao => "Descricao"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
  end
end
