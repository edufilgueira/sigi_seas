require 'rails_helper'

RSpec.describe "socioeduk/infracoes/index", type: :view do
  before(:each) do
    assign(:socioeduk_infracoes, [
      Socioeduk::Infracao.create!(
        :jovem => nil,
        :tipo_infracao => nil
      ),
      Socioeduk::Infracao.create!(
        :jovem => nil,
        :tipo_infracao => nil
      )
    ])
  end

  it "renders a list of socioeduk/infracoes" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
  end
end
