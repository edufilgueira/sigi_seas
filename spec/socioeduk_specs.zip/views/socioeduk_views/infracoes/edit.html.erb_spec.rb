require 'rails_helper'

RSpec.describe "socioeduk/infracoes/edit", type: :view do
  before(:each) do
    @socioeduk_infracao = assign(:socioeduk_infracao, Socioeduk::Infracao.create!(
      :jovem => nil,
      :tipo_infracao => nil
    ))
  end

  it "renders the edit socioeduk_infracao form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_infracao_path(@socioeduk_infracao), "post" do

      assert_select "input[name=?]", "socioeduk_infracao[jovem_id]"

      assert_select "input[name=?]", "socioeduk_infracao[tipo_infracao_id]"
    end
  end
end
