require 'rails_helper'

RSpec.describe "socioeduk/infracoes/new", type: :view do
  before(:each) do
    assign(:socioeduk_infracao, Socioeduk::Infracao.new(
      :jovem => nil,
      :tipo_infracao => nil
    ))
  end

  it "renders new socioeduk_infracao form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_infracoes_path, "post" do

      assert_select "input[name=?]", "socioeduk_infracao[jovem_id]"

      assert_select "input[name=?]", "socioeduk_infracao[tipo_infracao_id]"
    end
  end
end
