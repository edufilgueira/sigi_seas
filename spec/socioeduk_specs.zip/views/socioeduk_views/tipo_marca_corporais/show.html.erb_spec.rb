require 'rails_helper'

RSpec.describe "socioeduk/tipo_marca_corporais/show", type: :view do
  before(:each) do
    @socioeduk_tipo_marca_corporal = assign(:socioeduk_tipo_marca_corporal, Socioeduk::TipoMarcaCorporal.create!(
      :descricao => "Descricao"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
  end
end
