require 'rails_helper'

RSpec.describe "socioeduk/tipo_marca_corporais/index", type: :view do
  before(:each) do
    assign(:socioeduk_tipo_marca_corporais, [
      Socioeduk::TipoMarcaCorporal.create!(
        :descricao => "Descricao"
      ),
      Socioeduk::TipoMarcaCorporal.create!(
        :descricao => "Descricao"
      )
    ])
  end

  it "renders a list of socioeduk/tipo_marca_corporais" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
  end
end
