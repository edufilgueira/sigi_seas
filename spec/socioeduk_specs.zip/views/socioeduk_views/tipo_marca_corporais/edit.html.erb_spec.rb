require 'rails_helper'

RSpec.describe "socioeduk/tipo_marca_corporais/edit", type: :view do
  before(:each) do
    @socioeduk_tipo_marca_corporal = assign(:socioeduk_tipo_marca_corporal, Socioeduk::TipoMarcaCorporal.create!(
      :descricao => "MyString"
    ))
  end

  it "renders the edit socioeduk_tipo_marca_corporal form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_tipo_marca_corporal_path(@socioeduk_tipo_marca_corporal), "post" do

      assert_select "input[name=?]", "socioeduk_tipo_marca_corporal[descricao]"
    end
  end
end
