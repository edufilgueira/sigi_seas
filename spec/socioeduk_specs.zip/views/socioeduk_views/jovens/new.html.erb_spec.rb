require 'rails_helper'

RSpec.describe "socioeduk/jovens/new", type: :view do
  before(:each) do
    assign(:socioeduk_jovem, Socioeduk::Jovem.new(
      :nome => "MyString",
      :apelido => "MyString",
      :falecido => false,
      :sexo => 1,
      :opcao_sexual => nil,
      :nome_mae => "MyString",
      :nome_pai => "MyString",
      :peso => "",
      :altura => "",
      :dependente_quimico => false,
      :nacionalidade => "MyString",
      :naturalidade => "MyString",
      :etnia => "MyString",
      :estado_civil_id => "MyString",
      :orfao => false,
      :responsavel => "MyString",
      :mora_com => "MyString",
      :numero_filhos => 1,
      :responsavel_filhos => "MyString",
      :tempo_gestacao => "MyString",
      :amamentando => false,
      :foto => ""
    ))
  end

  it "renders new socioeduk_jovem form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_jovens_path, "post" do

      assert_select "input[name=?]", "socioeduk_jovem[nome]"

      assert_select "input[name=?]", "socioeduk_jovem[apelido]"

      assert_select "input[name=?]", "socioeduk_jovem[falecido]"

      assert_select "input[name=?]", "socioeduk_jovem[sexo]"

      assert_select "input[name=?]", "socioeduk_jovem[opcao_sexual_id]"

      assert_select "input[name=?]", "socioeduk_jovem[nome_mae]"

      assert_select "input[name=?]", "socioeduk_jovem[nome_pai]"

      assert_select "input[name=?]", "socioeduk_jovem[peso]"

      assert_select "input[name=?]", "socioeduk_jovem[altura]"

      assert_select "input[name=?]", "socioeduk_jovem[dependente_quimico]"

      assert_select "input[name=?]", "socioeduk_jovem[nacionalidade]"

      assert_select "input[name=?]", "socioeduk_jovem[naturalidade]"

      assert_select "input[name=?]", "socioeduk_jovem[etnia]"

      assert_select "input[name=?]", "socioeduk_jovem[estado_civil_id]"

      assert_select "input[name=?]", "socioeduk_jovem[orfao]"

      assert_select "input[name=?]", "socioeduk_jovem[responsavel]"

      assert_select "input[name=?]", "socioeduk_jovem[mora_com]"

      assert_select "input[name=?]", "socioeduk_jovem[numero_filhos]"

      assert_select "input[name=?]", "socioeduk_jovem[responsavel_filhos]"

      assert_select "input[name=?]", "socioeduk_jovem[tempo_gestacao]"

      assert_select "input[name=?]", "socioeduk_jovem[amamentando]"

      assert_select "input[name=?]", "socioeduk_jovem[foto]"
    end
  end
end
