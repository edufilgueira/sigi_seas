require 'rails_helper'

RSpec.describe "socioeduk/jovens/index", type: :view do
  before(:each) do
    assign(:socioeduk_jovens, [
      Socioeduk::Jovem.create!(
        :nome => "Nome",
        :apelido => "Apelido",
        :falecido => false,
        :sexo => 2,
        :opcao_sexual => nil,
        :nome_mae => "Nome Mae",
        :nome_pai => "Nome Pai",
        :peso => "",
        :altura => "",
        :dependente_quimico => false,
        :nacionalidade => "Nacionalidade",
        :naturalidade => "Naturalidade",
        :etnia => "Etnia",
        :estado_civil_id => "Estado Civil",
        :orfao => false,
        :responsavel => "Responsavel",
        :mora_com => "Mora Com",
        :numero_filhos => 3,
        :responsavel_filhos => "Responsavel Filhos",
        :tempo_gestacao => "Tempo Gestacao",
        :amamentando => false,
        :foto => ""
      ),
      Socioeduk::Jovem.create!(
        :nome => "Nome",
        :apelido => "Apelido",
        :falecido => false,
        :sexo => 2,
        :opcao_sexual => nil,
        :nome_mae => "Nome Mae",
        :nome_pai => "Nome Pai",
        :peso => "",
        :altura => "",
        :dependente_quimico => false,
        :nacionalidade => "Nacionalidade",
        :naturalidade => "Naturalidade",
        :etnia => "Etnia",
        :estado_civil_id => "Estado Civil",
        :orfao => false,
        :responsavel => "Responsavel",
        :mora_com => "Mora Com",
        :numero_filhos => 3,
        :responsavel_filhos => "Responsavel Filhos",
        :tempo_gestacao => "Tempo Gestacao",
        :amamentando => false,
        :foto => ""
      )
    ])
  end

  it "renders a list of socioeduk/jovens" do
    render
    assert_select "tr>td", :text => "Nome".to_s, :count => 2
    assert_select "tr>td", :text => "Apelido".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => "Nome Mae".to_s, :count => 2
    assert_select "tr>td", :text => "Nome Pai".to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => "Nacionalidade".to_s, :count => 2
    assert_select "tr>td", :text => "Naturalidade".to_s, :count => 2
    assert_select "tr>td", :text => "Etnia".to_s, :count => 2
    assert_select "tr>td", :text => "Estado Civil".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => "Responsavel".to_s, :count => 2
    assert_select "tr>td", :text => "Mora Com".to_s, :count => 2
    assert_select "tr>td", :text => 3.to_s, :count => 2
    assert_select "tr>td", :text => "Responsavel Filhos".to_s, :count => 2
    assert_select "tr>td", :text => "Tempo Gestacao".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
  end
end
