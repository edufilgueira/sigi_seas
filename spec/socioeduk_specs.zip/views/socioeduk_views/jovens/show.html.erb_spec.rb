require 'rails_helper'

RSpec.describe "socioeduk/jovens/show", type: :view do
  before(:each) do
    @socioeduk_jovem = assign(:socioeduk_jovem, Socioeduk::Jovem.create!(
      :nome => "Nome",
      :apelido => "Apelido",
      :falecido => false,
      :sexo => 2,
      :opcao_sexual => nil,
      :nome_mae => "Nome Mae",
      :nome_pai => "Nome Pai",
      :peso => "",
      :altura => "",
      :dependente_quimico => false,
      :nacionalidade => "Nacionalidade",
      :naturalidade => "Naturalidade",
      :etnia => "Etnia",
      :estado_civil_id => "Estado Civil",
      :orfao => false,
      :responsavel => "Responsavel",
      :mora_com => "Mora Com",
      :numero_filhos => 3,
      :responsavel_filhos => "Responsavel Filhos",
      :tempo_gestacao => "Tempo Gestacao",
      :amamentando => false,
      :foto => ""
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Nome/)
    expect(rendered).to match(/Apelido/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/2/)
    expect(rendered).to match(//)
    expect(rendered).to match(/Nome Mae/)
    expect(rendered).to match(/Nome Pai/)
    expect(rendered).to match(//)
    expect(rendered).to match(//)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/Nacionalidade/)
    expect(rendered).to match(/Naturalidade/)
    expect(rendered).to match(/Etnia/)
    expect(rendered).to match(/Estado Civil/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/Responsavel/)
    expect(rendered).to match(/Mora Com/)
    expect(rendered).to match(/3/)
    expect(rendered).to match(/Responsavel Filhos/)
    expect(rendered).to match(/Tempo Gestacao/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(//)
  end
end
