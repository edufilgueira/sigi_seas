require 'rails_helper'

RSpec.describe "socioeduk/tipo_deficiencias/index", type: :view do
  before(:each) do
    assign(:socioeduk_tipo_deficiencias, [
      Socioeduk::TipoDeficiencia.create!(
        :descricao => "Descricao"
      ),
      Socioeduk::TipoDeficiencia.create!(
        :descricao => "Descricao"
      )
    ])
  end

  it "renders a list of socioeduk/tipo_deficiencias" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
  end
end
