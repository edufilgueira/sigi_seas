require 'rails_helper'

RSpec.describe "socioeduk/tipo_deficiencias/new", type: :view do
  before(:each) do
    assign(:socioeduk_tipo_deficiencia, Socioeduk::TipoDeficiencia.new(
      :descricao => "MyString"
    ))
  end

  it "renders new socioeduk_tipo_deficiencia form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_tipo_deficiencias_path, "post" do

      assert_select "input[name=?]", "socioeduk_tipo_deficiencia[descricao]"
    end
  end
end
