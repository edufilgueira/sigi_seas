require 'rails_helper'

RSpec.describe "socioeduk/atendimento_iniciais/edit", type: :view do
  before(:each) do
    @socioeduk_atendimento_inicial = assign(:socioeduk_atendimento_inicial, Socioeduk::AtendimentoInicial.create!(
      :jovem => nil,
      :unidade_socioeducativa => nil,
      :reincidente => false,
      :cumpre_medida => false,
      :qual_medida => "MyString",
      :cidade_infracao => "MyString",
      :bairro_infracao => "MyString",
      :busca_apreensao => false,
      :cidade_origem_processo => 1,
      :cidade_execucao_processo => 1,
      :numero_oficio_bo => "MyString",
      :comarca_origem => "MyString",
      :procedencia => "MyString",
      :numero_processo => "MyString",
      :guia_corpo_delito => false,
      :alcoolizado => false,
      :drogado => false,
      :ematomas => false,
      :agressor => "MyString",
      :observacoes => "MyText",
      :nome_condutor => "MyString",
      :funcao_condutor => "MyString",
      :rg_condutor => "MyString",
      :encaminhado => false,
      :tipo_desligamento => nil
    ))
  end

  it "renders the edit socioeduk_atendimento_inicial form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_atendimento_inicial_path(@socioeduk_atendimento_inicial), "post" do

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[jovem_id]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[unidade_socioeducativa_id]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[reincidente]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[cumpre_medida]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[qual_medida]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[cidade_infracao]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[bairro_infracao]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[busca_apreensao]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[cidade_origem_processo]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[cidade_execucao_processo]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[numero_oficio_bo]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[comarca_origem]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[procedencia]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[numero_processo]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[guia_corpo_delito]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[alcoolizado]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[drogado]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[ematomas]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[agressor]"

      assert_select "textarea[name=?]", "socioeduk_atendimento_inicial[observacoes]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[nome_condutor]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[funcao_condutor]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[rg_condutor]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[encaminhado]"

      assert_select "input[name=?]", "socioeduk_atendimento_inicial[tipo_desligamento_id]"
    end
  end
end
