require 'rails_helper'

RSpec.describe "socioeduk/atendimento_iniciais/show", type: :view do
  before(:each) do
    @socioeduk_atendimento_inicial = assign(:socioeduk_atendimento_inicial, Socioeduk::AtendimentoInicial.create!(
      :jovem => nil,
      :unidade_socioeducativa => nil,
      :reincidente => false,
      :cumpre_medida => false,
      :qual_medida => "Qual Medida",
      :cidade_infracao => "Cidade Infracao",
      :bairro_infracao => "Bairro Infracao",
      :busca_apreensao => false,
      :cidade_origem_processo => 2,
      :cidade_execucao_processo => 3,
      :numero_oficio_bo => "Numero Oficio Bo",
      :comarca_origem => "Comarca Origem",
      :procedencia => "Procedencia",
      :numero_processo => "Numero Processo",
      :guia_corpo_delito => false,
      :alcoolizado => false,
      :drogado => false,
      :ematomas => false,
      :agressor => "Agressor",
      :observacoes => "MyText",
      :nome_condutor => "Nome Condutor",
      :funcao_condutor => "Funcao Condutor",
      :rg_condutor => "Rg Condutor",
      :encaminhado => false,
      :tipo_desligamento => nil
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(//)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/Qual Medida/)
    expect(rendered).to match(/Cidade Infracao/)
    expect(rendered).to match(/Bairro Infracao/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/2/)
    expect(rendered).to match(/3/)
    expect(rendered).to match(/Numero Oficio Bo/)
    expect(rendered).to match(/Comarca Origem/)
    expect(rendered).to match(/Procedencia/)
    expect(rendered).to match(/Numero Processo/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(/Agressor/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/Nome Condutor/)
    expect(rendered).to match(/Funcao Condutor/)
    expect(rendered).to match(/Rg Condutor/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(//)
  end
end
