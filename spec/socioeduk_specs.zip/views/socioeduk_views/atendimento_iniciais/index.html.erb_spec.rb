require 'rails_helper'

RSpec.describe "socioeduk/atendimento_iniciais/index", type: :view do
  before(:each) do
    assign(:socioeduk_atendimento_iniciais, [
      Socioeduk::AtendimentoInicial.create!(
        :jovem => nil,
        :unidade_socioeducativa => nil,
        :reincidente => false,
        :cumpre_medida => false,
        :qual_medida => "Qual Medida",
        :cidade_infracao => "Cidade Infracao",
        :bairro_infracao => "Bairro Infracao",
        :busca_apreensao => false,
        :cidade_origem_processo => 2,
        :cidade_execucao_processo => 3,
        :numero_oficio_bo => "Numero Oficio Bo",
        :comarca_origem => "Comarca Origem",
        :procedencia => "Procedencia",
        :numero_processo => "Numero Processo",
        :guia_corpo_delito => false,
        :alcoolizado => false,
        :drogado => false,
        :ematomas => false,
        :agressor => "Agressor",
        :observacoes => "MyText",
        :nome_condutor => "Nome Condutor",
        :funcao_condutor => "Funcao Condutor",
        :rg_condutor => "Rg Condutor",
        :encaminhado => false,
        :tipo_desligamento => nil
      ),
      Socioeduk::AtendimentoInicial.create!(
        :jovem => nil,
        :unidade_socioeducativa => nil,
        :reincidente => false,
        :cumpre_medida => false,
        :qual_medida => "Qual Medida",
        :cidade_infracao => "Cidade Infracao",
        :bairro_infracao => "Bairro Infracao",
        :busca_apreensao => false,
        :cidade_origem_processo => 2,
        :cidade_execucao_processo => 3,
        :numero_oficio_bo => "Numero Oficio Bo",
        :comarca_origem => "Comarca Origem",
        :procedencia => "Procedencia",
        :numero_processo => "Numero Processo",
        :guia_corpo_delito => false,
        :alcoolizado => false,
        :drogado => false,
        :ematomas => false,
        :agressor => "Agressor",
        :observacoes => "MyText",
        :nome_condutor => "Nome Condutor",
        :funcao_condutor => "Funcao Condutor",
        :rg_condutor => "Rg Condutor",
        :encaminhado => false,
        :tipo_desligamento => nil
      )
    ])
  end

  it "renders a list of socioeduk/atendimento_iniciais" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => "Qual Medida".to_s, :count => 2
    assert_select "tr>td", :text => "Cidade Infracao".to_s, :count => 2
    assert_select "tr>td", :text => "Bairro Infracao".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => 3.to_s, :count => 2
    assert_select "tr>td", :text => "Numero Oficio Bo".to_s, :count => 2
    assert_select "tr>td", :text => "Comarca Origem".to_s, :count => 2
    assert_select "tr>td", :text => "Procedencia".to_s, :count => 2
    assert_select "tr>td", :text => "Numero Processo".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => "Agressor".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "Nome Condutor".to_s, :count => 2
    assert_select "tr>td", :text => "Funcao Condutor".to_s, :count => 2
    assert_select "tr>td", :text => "Rg Condutor".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
  end
end
