require 'rails_helper'

RSpec.describe "socioeduk/documentos/index", type: :view do
  before(:each) do
    assign(:socioeduk_documentos, [
      Socioeduk::Documento.create!(
        :jovem => nil,
        :cpf => "Cpf",
        :rg_numero => "Rg Numero",
        :rg_orgao_emissor => "Rg Orgao Emissor",
        :rg_uf_emissao => "Rg Uf Emissao",
        :certidao_nascimento => "Certidao Nascimento",
        :certidao_numero => "Certidao Numero",
        :certidao_pagina => "Certidao Pagina",
        :certidao_livro => "Certidao Livro",
        :certidao_uf_emissao => "Certidao Uf Emissao",
        :cpts_numero => "Cpts Numero",
        :ctps_serie => "Ctps Serie",
        :ctps_data_emissao => "Ctps Data Emissao",
        :ctps_uf_emissao => "Ctps Uf Emissao",
        :titulo_numero => "Titulo Numero",
        :titulo_serie => "Titulo Serie",
        :titulo_secao => "Titulo Secao",
        :pis_numero => "Pis Numero",
        :reservista_numero => "Reservista Numero"
      ),
      Socioeduk::Documento.create!(
        :jovem => nil,
        :cpf => "Cpf",
        :rg_numero => "Rg Numero",
        :rg_orgao_emissor => "Rg Orgao Emissor",
        :rg_uf_emissao => "Rg Uf Emissao",
        :certidao_nascimento => "Certidao Nascimento",
        :certidao_numero => "Certidao Numero",
        :certidao_pagina => "Certidao Pagina",
        :certidao_livro => "Certidao Livro",
        :certidao_uf_emissao => "Certidao Uf Emissao",
        :cpts_numero => "Cpts Numero",
        :ctps_serie => "Ctps Serie",
        :ctps_data_emissao => "Ctps Data Emissao",
        :ctps_uf_emissao => "Ctps Uf Emissao",
        :titulo_numero => "Titulo Numero",
        :titulo_serie => "Titulo Serie",
        :titulo_secao => "Titulo Secao",
        :pis_numero => "Pis Numero",
        :reservista_numero => "Reservista Numero"
      )
    ])
  end

  it "renders a list of socioeduk/documentos" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => "Cpf".to_s, :count => 2
    assert_select "tr>td", :text => "Rg Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Rg Orgao Emissor".to_s, :count => 2
    assert_select "tr>td", :text => "Rg Uf Emissao".to_s, :count => 2
    assert_select "tr>td", :text => "Certidao Nascimento".to_s, :count => 2
    assert_select "tr>td", :text => "Certidao Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Certidao Pagina".to_s, :count => 2
    assert_select "tr>td", :text => "Certidao Livro".to_s, :count => 2
    assert_select "tr>td", :text => "Certidao Uf Emissao".to_s, :count => 2
    assert_select "tr>td", :text => "Cpts Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Ctps Serie".to_s, :count => 2
    assert_select "tr>td", :text => "Ctps Data Emissao".to_s, :count => 2
    assert_select "tr>td", :text => "Ctps Uf Emissao".to_s, :count => 2
    assert_select "tr>td", :text => "Titulo Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Titulo Serie".to_s, :count => 2
    assert_select "tr>td", :text => "Titulo Secao".to_s, :count => 2
    assert_select "tr>td", :text => "Pis Numero".to_s, :count => 2
    assert_select "tr>td", :text => "Reservista Numero".to_s, :count => 2
  end
end
