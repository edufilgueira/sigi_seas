require 'rails_helper'

RSpec.describe "socioeduk/documentos/edit", type: :view do
  before(:each) do
    @socioeduk_documento = assign(:socioeduk_documento, Socioeduk::Documento.create!(
      :jovem => nil,
      :cpf => "MyString",
      :rg_numero => "MyString",
      :rg_orgao_emissor => "MyString",
      :rg_uf_emissao => "MyString",
      :certidao_nascimento => "MyString",
      :certidao_numero => "MyString",
      :certidao_pagina => "MyString",
      :certidao_livro => "MyString",
      :certidao_uf_emissao => "MyString",
      :cpts_numero => "MyString",
      :ctps_serie => "MyString",
      :ctps_data_emissao => "MyString",
      :ctps_uf_emissao => "MyString",
      :titulo_numero => "MyString",
      :titulo_serie => "MyString",
      :titulo_secao => "MyString",
      :pis_numero => "MyString",
      :reservista_numero => "MyString"
    ))
  end

  it "renders the edit socioeduk_documento form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_documento_path(@socioeduk_documento), "post" do

      assert_select "input[name=?]", "socioeduk_documento[jovem_id]"

      assert_select "input[name=?]", "socioeduk_documento[cpf]"

      assert_select "input[name=?]", "socioeduk_documento[rg_numero]"

      assert_select "input[name=?]", "socioeduk_documento[rg_orgao_emissor]"

      assert_select "input[name=?]", "socioeduk_documento[rg_uf_emissao]"

      assert_select "input[name=?]", "socioeduk_documento[certidao_nascimento]"

      assert_select "input[name=?]", "socioeduk_documento[certidao_numero]"

      assert_select "input[name=?]", "socioeduk_documento[certidao_pagina]"

      assert_select "input[name=?]", "socioeduk_documento[certidao_livro]"

      assert_select "input[name=?]", "socioeduk_documento[certidao_uf_emissao]"

      assert_select "input[name=?]", "socioeduk_documento[cpts_numero]"

      assert_select "input[name=?]", "socioeduk_documento[ctps_serie]"

      assert_select "input[name=?]", "socioeduk_documento[ctps_data_emissao]"

      assert_select "input[name=?]", "socioeduk_documento[ctps_uf_emissao]"

      assert_select "input[name=?]", "socioeduk_documento[titulo_numero]"

      assert_select "input[name=?]", "socioeduk_documento[titulo_serie]"

      assert_select "input[name=?]", "socioeduk_documento[titulo_secao]"

      assert_select "input[name=?]", "socioeduk_documento[pis_numero]"

      assert_select "input[name=?]", "socioeduk_documento[reservista_numero]"
    end
  end
end
