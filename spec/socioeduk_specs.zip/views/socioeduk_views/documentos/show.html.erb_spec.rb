require 'rails_helper'

RSpec.describe "socioeduk/documentos/show", type: :view do
  before(:each) do
    @socioeduk_documento = assign(:socioeduk_documento, Socioeduk::Documento.create!(
      :jovem => nil,
      :cpf => "Cpf",
      :rg_numero => "Rg Numero",
      :rg_orgao_emissor => "Rg Orgao Emissor",
      :rg_uf_emissao => "Rg Uf Emissao",
      :certidao_nascimento => "Certidao Nascimento",
      :certidao_numero => "Certidao Numero",
      :certidao_pagina => "Certidao Pagina",
      :certidao_livro => "Certidao Livro",
      :certidao_uf_emissao => "Certidao Uf Emissao",
      :cpts_numero => "Cpts Numero",
      :ctps_serie => "Ctps Serie",
      :ctps_data_emissao => "Ctps Data Emissao",
      :ctps_uf_emissao => "Ctps Uf Emissao",
      :titulo_numero => "Titulo Numero",
      :titulo_serie => "Titulo Serie",
      :titulo_secao => "Titulo Secao",
      :pis_numero => "Pis Numero",
      :reservista_numero => "Reservista Numero"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(/Cpf/)
    expect(rendered).to match(/Rg Numero/)
    expect(rendered).to match(/Rg Orgao Emissor/)
    expect(rendered).to match(/Rg Uf Emissao/)
    expect(rendered).to match(/Certidao Nascimento/)
    expect(rendered).to match(/Certidao Numero/)
    expect(rendered).to match(/Certidao Pagina/)
    expect(rendered).to match(/Certidao Livro/)
    expect(rendered).to match(/Certidao Uf Emissao/)
    expect(rendered).to match(/Cpts Numero/)
    expect(rendered).to match(/Ctps Serie/)
    expect(rendered).to match(/Ctps Data Emissao/)
    expect(rendered).to match(/Ctps Uf Emissao/)
    expect(rendered).to match(/Titulo Numero/)
    expect(rendered).to match(/Titulo Serie/)
    expect(rendered).to match(/Titulo Secao/)
    expect(rendered).to match(/Pis Numero/)
    expect(rendered).to match(/Reservista Numero/)
  end
end
