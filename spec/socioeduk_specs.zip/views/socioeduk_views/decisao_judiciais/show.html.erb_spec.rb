require 'rails_helper'

RSpec.describe "socioeduk/decisao_judiciais/show", type: :view do
  before(:each) do
    @socioeduk_decisao_judicial = assign(:socioeduk_decisao_judicial, Socioeduk::DecisaoJudicial.create!(
      :descricao => "Descricao",
      :atendimento_inicial => nil,
      :documento => ""
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
    expect(rendered).to match(//)
    expect(rendered).to match(//)
  end
end
