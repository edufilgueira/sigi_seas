require 'rails_helper'

RSpec.describe "socioeduk/decisao_judiciais/edit", type: :view do
  before(:each) do
    @socioeduk_decisao_judicial = assign(:socioeduk_decisao_judicial, Socioeduk::DecisaoJudicial.create!(
      :descricao => "MyString",
      :atendimento_inicial => nil,
      :documento => ""
    ))
  end

  it "renders the edit socioeduk_decisao_judicial form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_decisao_judicial_path(@socioeduk_decisao_judicial), "post" do

      assert_select "input[name=?]", "socioeduk_decisao_judicial[descricao]"

      assert_select "input[name=?]", "socioeduk_decisao_judicial[atendimento_inicial_id]"

      assert_select "input[name=?]", "socioeduk_decisao_judicial[documento]"
    end
  end
end
