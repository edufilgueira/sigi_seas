require 'rails_helper'

RSpec.describe "socioeduk/decisao_judiciais/new", type: :view do
  before(:each) do
    assign(:socioeduk_decisao_judicial, Socioeduk::DecisaoJudicial.new(
      :descricao => "MyString",
      :atendimento_inicial => nil,
      :documento => ""
    ))
  end

  it "renders new socioeduk_decisao_judicial form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_decisao_judiciais_path, "post" do

      assert_select "input[name=?]", "socioeduk_decisao_judicial[descricao]"

      assert_select "input[name=?]", "socioeduk_decisao_judicial[atendimento_inicial_id]"

      assert_select "input[name=?]", "socioeduk_decisao_judicial[documento]"
    end
  end
end
