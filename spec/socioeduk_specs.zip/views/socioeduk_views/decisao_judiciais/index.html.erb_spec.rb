require 'rails_helper'

RSpec.describe "socioeduk/decisao_judiciais/index", type: :view do
  before(:each) do
    assign(:socioeduk_decisao_judiciais, [
      Socioeduk::DecisaoJudicial.create!(
        :descricao => "Descricao",
        :atendimento_inicial => nil,
        :documento => ""
      ),
      Socioeduk::DecisaoJudicial.create!(
        :descricao => "Descricao",
        :atendimento_inicial => nil,
        :documento => ""
      )
    ])
  end

  it "renders a list of socioeduk/decisao_judiciais" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
  end
end
