require 'rails_helper'

RSpec.describe "socioeduk/admissao_anexos/edit", type: :view do
  before(:each) do
    @socioeduk_admissao_anexo = assign(:socioeduk_admissao_anexo, Socioeduk::AdmissaoAnexo.create!(
      :jovem => nil,
      :kit => "",
      :documentos => ""
    ))
  end

  it "renders the edit socioeduk_admissao_anexo form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_admissao_anexo_path(@socioeduk_admissao_anexo), "post" do

      assert_select "input[name=?]", "socioeduk_admissao_anexo[jovem_id]"

      assert_select "input[name=?]", "socioeduk_admissao_anexo[kit]"

      assert_select "input[name=?]", "socioeduk_admissao_anexo[documentos]"
    end
  end
end
