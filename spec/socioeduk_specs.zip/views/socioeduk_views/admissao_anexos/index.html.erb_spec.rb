require 'rails_helper'

RSpec.describe "socioeduk/admissao_anexos/index", type: :view do
  before(:each) do
    assign(:socioeduk_admissao_anexos, [
      Socioeduk::AdmissaoAnexo.create!(
        :jovem => nil,
        :kit => "",
        :documentos => ""
      ),
      Socioeduk::AdmissaoAnexo.create!(
        :jovem => nil,
        :kit => "",
        :documentos => ""
      )
    ])
  end

  it "renders a list of socioeduk/admissao_anexos" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
    assert_select "tr>td", :text => "".to_s, :count => 2
  end
end
