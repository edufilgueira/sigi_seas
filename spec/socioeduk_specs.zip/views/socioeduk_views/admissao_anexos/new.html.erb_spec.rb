require 'rails_helper'

RSpec.describe "socioeduk/admissao_anexos/new", type: :view do
  before(:each) do
    assign(:socioeduk_admissao_anexo, Socioeduk::AdmissaoAnexo.new(
      :jovem => nil,
      :kit => "",
      :documentos => ""
    ))
  end

  it "renders new socioeduk_admissao_anexo form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_admissao_anexos_path, "post" do

      assert_select "input[name=?]", "socioeduk_admissao_anexo[jovem_id]"

      assert_select "input[name=?]", "socioeduk_admissao_anexo[kit]"

      assert_select "input[name=?]", "socioeduk_admissao_anexo[documentos]"
    end
  end
end
