require 'rails_helper'

RSpec.describe "socioeduk/documento_forma_entradas/index", type: :view do
  before(:each) do
    assign(:socioeduk_documento_forma_entradas, [
      Socioeduk::DocumentoFormaEntrada.create!(
        :descricao => "Descricao",
        :obrigatorio => false,
        :forma_entrada => nil,
        :subforma_entrada => nil
      ),
      Socioeduk::DocumentoFormaEntrada.create!(
        :descricao => "Descricao",
        :obrigatorio => false,
        :forma_entrada => nil,
        :subforma_entrada => nil
      )
    ])
  end

  it "renders a list of socioeduk/documento_forma_entradas" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
    assert_select "tr>td", :text => false.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
  end
end
