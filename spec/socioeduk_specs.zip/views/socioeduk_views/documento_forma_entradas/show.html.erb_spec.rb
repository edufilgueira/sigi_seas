require 'rails_helper'

RSpec.describe "socioeduk/documento_forma_entradas/show", type: :view do
  before(:each) do
    @socioeduk_documento_forma_entrada = assign(:socioeduk_documento_forma_entrada, Socioeduk::DocumentoFormaEntrada.create!(
      :descricao => "Descricao",
      :obrigatorio => false,
      :forma_entrada => nil,
      :subforma_entrada => nil
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Descricao/)
    expect(rendered).to match(/false/)
    expect(rendered).to match(//)
    expect(rendered).to match(//)
  end
end
