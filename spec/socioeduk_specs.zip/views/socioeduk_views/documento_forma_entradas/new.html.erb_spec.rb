require 'rails_helper'

RSpec.describe "socioeduk/documento_forma_entradas/new", type: :view do
  before(:each) do
    assign(:socioeduk_documento_forma_entrada, Socioeduk::DocumentoFormaEntrada.new(
      :descricao => "MyString",
      :obrigatorio => false,
      :forma_entrada => nil,
      :subforma_entrada => nil
    ))
  end

  it "renders new socioeduk_documento_forma_entrada form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_documento_forma_entradas_path, "post" do

      assert_select "input[name=?]", "socioeduk_documento_forma_entrada[descricao]"

      assert_select "input[name=?]", "socioeduk_documento_forma_entrada[obrigatorio]"

      assert_select "input[name=?]", "socioeduk_documento_forma_entrada[forma_entrada_id]"

      assert_select "input[name=?]", "socioeduk_documento_forma_entrada[subforma_entrada_id]"
    end
  end
end
