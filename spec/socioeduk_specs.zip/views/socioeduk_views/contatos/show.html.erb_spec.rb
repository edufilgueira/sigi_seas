require 'rails_helper'

RSpec.describe "socioeduk/contatos/show", type: :view do
  before(:each) do
    @socioeduk_contato = assign(:socioeduk_contato, Socioeduk::Contato.create!(
      :jovem => nil,
      :tipo_contato => nil,
      :ddd => 2,
      :numero => "Numero"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(//)
    expect(rendered).to match(//)
    expect(rendered).to match(/2/)
    expect(rendered).to match(/Numero/)
  end
end
