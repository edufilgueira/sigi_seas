require 'rails_helper'

RSpec.describe "socioeduk/contatos/index", type: :view do
  before(:each) do
    assign(:socioeduk_contatos, [
      Socioeduk::Contato.create!(
        :jovem => nil,
        :tipo_contato => nil,
        :ddd => 2,
        :numero => "Numero"
      ),
      Socioeduk::Contato.create!(
        :jovem => nil,
        :tipo_contato => nil,
        :ddd => 2,
        :numero => "Numero"
      )
    ])
  end

  it "renders a list of socioeduk/contatos" do
    render
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => nil.to_s, :count => 2
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => "Numero".to_s, :count => 2
  end
end
