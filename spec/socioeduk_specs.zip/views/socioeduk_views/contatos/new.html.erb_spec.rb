require 'rails_helper'

RSpec.describe "socioeduk/contatos/new", type: :view do
  before(:each) do
    assign(:socioeduk_contato, Socioeduk::Contato.new(
      :jovem => nil,
      :tipo_contato => nil,
      :ddd => 1,
      :numero => "MyString"
    ))
  end

  it "renders new socioeduk_contato form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_contatos_path, "post" do

      assert_select "input[name=?]", "socioeduk_contato[jovem_id]"

      assert_select "input[name=?]", "socioeduk_contato[tipo_contato_id]"

      assert_select "input[name=?]", "socioeduk_contato[ddd]"

      assert_select "input[name=?]", "socioeduk_contato[numero]"
    end
  end
end
