require 'rails_helper'

RSpec.describe "socioeduk/contatos/edit", type: :view do
  before(:each) do
    @socioeduk_contato = assign(:socioeduk_contato, Socioeduk::Contato.create!(
      :jovem => nil,
      :tipo_contato => nil,
      :ddd => 1,
      :numero => "MyString"
    ))
  end

  it "renders the edit socioeduk_contato form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_contato_path(@socioeduk_contato), "post" do

      assert_select "input[name=?]", "socioeduk_contato[jovem_id]"

      assert_select "input[name=?]", "socioeduk_contato[tipo_contato_id]"

      assert_select "input[name=?]", "socioeduk_contato[ddd]"

      assert_select "input[name=?]", "socioeduk_contato[numero]"
    end
  end
end
