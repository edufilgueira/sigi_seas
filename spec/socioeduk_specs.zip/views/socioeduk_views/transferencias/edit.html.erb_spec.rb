require 'rails_helper'

RSpec.describe "socioeduk/transferencias/edit", type: :view do
  before(:each) do
    @socioeduk_transferencia = assign(:socioeduk_transferencia, Socioeduk::Transferencia.create!(
      :unidade_socioeducativa_origem_id => 1,
      :unidade_socioeducativa_destino_id => 1,
      :admissao => nil
    ))
  end

  it "renders the edit socioeduk_transferencia form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_transferencia_path(@socioeduk_transferencia), "post" do

      assert_select "input[name=?]", "socioeduk_transferencia[unidade_socioeducativa_origem_id]"

      assert_select "input[name=?]", "socioeduk_transferencia[unidade_socioeducativa_destino_id]"

      assert_select "input[name=?]", "socioeduk_transferencia[admissao_id]"
    end
  end
end
