require 'rails_helper'

RSpec.describe "socioeduk/opcao_sexuais/index", type: :view do
  before(:each) do
    assign(:socioeduk_opcao_sexuais, [
      Socioeduk::OpcaoSexual.create!(
        :descricao => "Descricao"
      ),
      Socioeduk::OpcaoSexual.create!(
        :descricao => "Descricao"
      )
    ])
  end

  it "renders a list of socioeduk/opcao_sexuais" do
    render
    assert_select "tr>td", :text => "Descricao".to_s, :count => 2
  end
end
