require 'rails_helper'

RSpec.describe "socioeduk/opcao_sexuais/new", type: :view do
  before(:each) do
    assign(:socioeduk_opcao_sexual, Socioeduk::OpcaoSexual.new(
      :descricao => "MyString"
    ))
  end

  it "renders new socioeduk_opcao_sexual form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_opcao_sexuais_path, "post" do

      assert_select "input[name=?]", "socioeduk_opcao_sexual[descricao]"
    end
  end
end
