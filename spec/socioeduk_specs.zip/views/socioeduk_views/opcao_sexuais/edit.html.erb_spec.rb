require 'rails_helper'

RSpec.describe "socioeduk/opcao_sexuais/edit", type: :view do
  before(:each) do
    @socioeduk_opcao_sexual = assign(:socioeduk_opcao_sexual, Socioeduk::OpcaoSexual.create!(
      :descricao => "MyString"
    ))
  end

  it "renders the edit socioeduk_opcao_sexual form" do
    render

    assert_select "form[action=?][method=?]", socioeduk_opcao_sexual_path(@socioeduk_opcao_sexual), "post" do

      assert_select "input[name=?]", "socioeduk_opcao_sexual[descricao]"
    end
  end
end
