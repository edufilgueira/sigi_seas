require 'rails_helper'

RSpec.describe "Socioeduk::AdmissaoAnexos", type: :request do
  describe "GET /socioeduk_admissao_anexos" do
    it "works! (now write some real specs)" do
      get socioeduk_admissao_anexos_path
      expect(response).to have_http_status(200)
    end
  end
end
