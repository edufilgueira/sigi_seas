require 'rails_helper'

RSpec.describe "Socioeduk::TipoInfracoes", type: :request do
  describe "GET /socioeduk_tipo_infracoes" do
    it "works! (now write some real specs)" do
      get socioeduk_tipo_infracoes_path
      expect(response).to have_http_status(200)
    end
  end
end
