require 'rails_helper'

RSpec.describe "Socioeduk::TipoDeficiencias", type: :request do
  describe "GET /socioeduk_tipo_deficiencias" do
    it "works! (now write some real specs)" do
      get socioeduk_tipo_deficiencias_path
      expect(response).to have_http_status(200)
    end
  end
end
