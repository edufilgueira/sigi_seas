require 'rails_helper'

RSpec.describe "Socioeduk::TipoMarcaCorporais", type: :request do
  describe "GET /socioeduk_tipo_marca_corporais" do
    it "works! (now write some real specs)" do
      get socioeduk_tipo_marca_corporais_path
      expect(response).to have_http_status(200)
    end
  end
end
